<?php
include 'db.php';
if(isset($_POST['submit'])){
    $student_id = $_POST['student_id'];
    $name = $_POST['name'];
    $relation = $_POST['relation'];
    $contact = $_POST['contact'];
    $stmt = $conn->prepare("INSERT INTO guardians (student_id,name,relation,contact) VALUES (?,?,?,?)");
    $stmt->bind_param("isss",$student_id,$name,$relation,$contact);
    $stmt->execute();
    $stmt->close();
    $message = "Guardian added successfully!";
}
$students = $conn->query("SELECT id,name FROM students");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Add Guardian</title>
<link rel="stylesheet" href="assets/css/bootstrap.min.css">
<style>
body { background-color: #f8f9fa; }
h2 { color: #001f3f; }
.btn-primary { background-color: #001f3f; border-color: #001f3f; }
</style>
</head>
<body>
<div class="container mt-5">
<h2>Add Guardian</h2>
<?php if(isset($message)) echo "<div class='alert alert-success'>$message</div>"; ?>
<form method="POST" class="mt-3">
  <div class="mb-3">
    <label class="form-label">Select Student:</label>
    <select name="student_id" class="form-control" required>
      <option value="">--Select--</option>
      <?php while($row=$students->fetch_assoc()): ?>
        <option value="<?php echo $row['id']; ?>"><?php echo $row['name']; ?></option>
      <?php endwhile; ?>
    </select>
  </div>
  <div class="mb-3">
    <label class="form-label">Guardian Name:</label>
    <input type="text" name="name" class="form-control" required>
  </div>
  <div class="mb-3">
    <label class="form-label">Relation:</label>
    <input type="text" name="relation" class="form-control" required>
  </div>
  <div class="mb-3">
    <label class="form-label">Contact:</label>
    <input type="text" name="contact" class="form-control" required>
  </div>
  <button type="submit" name="submit" class="btn btn-primary">Add Guardian</button>
</form>
</div>
<script src="assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>
