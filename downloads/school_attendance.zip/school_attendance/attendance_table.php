<?php
include 'db.php';

$res = $conn->query("SELECT a.id, s.name as student, a.method, a.timestamp 
                     FROM attendance_log a 
                     JOIN students s ON a.student_id = s.id 
                     ORDER BY a.timestamp DESC");

if($res->num_rows > 0){
    echo "<table class='table table-striped table-bordered'>
            <thead class='table-dark'>
              <tr><th>ID</th><th>Student</th><th>Method</th><th>Time</th></tr>
            </thead><tbody>";
    while($row = $res->fetch_assoc()){
        echo "<tr>
                <td>{$row['id']}</td>
                <td>{$row['student']}</td>
                <td>{$row['method']}</td>
                <td>{$row['timestamp']}</td>
              </tr>";
    }
    echo "</tbody></table>";
}else{
    echo "<div class='alert alert-info'>No attendance records found.</div>";
}
?>
