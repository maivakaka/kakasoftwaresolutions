<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Scan QR</title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <script src="assets/js/html5-qrcode.min.js"></script>
    <style>
        body { background-color: #f8f9fa; }
        h2 { color: #001f3f; }
        #reader { margin-top: 20px; }
    </style>
</head>
<body>
<div class="container mt-5">
    <h2>Scan Student QR Code</h2>
    <div id="reader" style="width:300px;"></div>
</div>

<script>
function onScanSuccess(decodedText, decodedResult) {
    alert("Student QR: " + decodedText);
    fetch('log_qr.php', {
        method: 'POST',
        headers: {'Content-Type':'application/x-www-form-urlencoded'},
        body: 'qr_code=' + decodedText
    }).then(res => res.text()).then(data => alert(data));
}
var html5QrcodeScanner = new Html5QrcodeScanner("reader", { fps: 10, qrbox: 250 });
html5QrcodeScanner.render(onScanSuccess);
</script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>
