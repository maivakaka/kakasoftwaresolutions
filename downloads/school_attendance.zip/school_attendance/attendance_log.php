<?php
include 'db.php';
$res = $conn->query("SELECT a.id, s.name as student, a.method, a.timestamp 
                     FROM attendance_log a 
                     JOIN students s ON a.student_id=s.id 
                     ORDER BY a.timestamp DESC");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Attendance Log</title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <style>
        body { background-color: #f8f9fa; }
        h2 { color: #001f3f; }
        .table thead { background-color: #001f3f; color: #ff851b; }
    </style>
</head>
<body>
<div class="container mt-5">
    <h2>Attendance Log</h2>
    <table class="table table-striped table-bordered mt-3">
        <thead>
            <tr><th>ID</th><th>Student</th><th>Method</th><th>Time</th></tr>
        </thead>
        <tbody>
        <?php while($row=$res->fetch_assoc()): ?>
            <tr>
                <td><?php echo $row['id']; ?></td>
                <td><?php echo $row['student']; ?></td>
                <td><?php echo $row['method']; ?></td>
                <td><?php echo $row['timestamp']; ?></td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
</div>
<script src="assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>
