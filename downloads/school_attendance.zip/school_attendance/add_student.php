<?php
include 'db.php';
$qr_code = '';
if(isset($_POST['submit'])){
    $name = $_POST['name'];
    $class = $_POST['class'];
    $photo = $_FILES['photo']['name'];
    $target = "assets/uploads/".basename($photo);
    $qr_code = uniqid('STU_');

    if(move_uploaded_file($_FILES['photo']['tmp_name'], $target)){
        $stmt = $conn->prepare("INSERT INTO students (name,class,photo,qr_code) VALUES (?,?,?,?)");
        $stmt->bind_param("ssss",$name,$class,$photo,$qr_code);
        $stmt->execute();
        $stmt->close();
        $message = "Student added successfully! QR Code generated below:";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Add Student</title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <script src="assets/js/qrcode.min.js"></script>
    <style>
        body { background-color: #f8f9fa; }
        h2 { color: #001f3f; }
        .btn-primary { background-color: #001f3f; border-color: #001f3f; }
        .btn-primary:hover { opacity: 0.9; }

        body { background-color: #f8f9fa; }
        .navbar { background-color: #001f3f; }
        .navbar-brand, .nav-link { color: #ff851b !important; }
        .btn-primary { background-color: #001f3f; border-color: #001f3f; }
        .btn-secondary { background-color: #ff851b; border-color: #ff851b; color: #fff; }
        
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">Synergy Junior School</a>
    </div>
</nav>
<div class="container mt-5">
    <h2>Add Student</h2>
    <?php if(isset($message)) echo "<div class='alert alert-success'>$message</div>"; ?>
    <form method="POST" enctype="multipart/form-data" class="mt-3">
        <div class="mb-3">
            <label class="form-label">Name:</label>
            <input type="text" name="name" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Class:</label>
            <input type="text" name="class" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Photo:</label>
            <input type="file" name="photo" class="form-control" required>
        </div>
        <button type="submit" name="submit" class="btn btn-primary">Add Student</button>
    </form>

    <?php if($qr_code): ?>
    <div class="mt-4">
        <h4>Generated QR Code:</h4>
        <div id="qrcode"></div>
        <script>
            var qrcode = new QRCode(document.getElementById("qrcode"), { text: "<?php echo $qr_code; ?>", width: 128, height: 128 });
        </script>
    </div>
    <?php endif; ?>
</div>
<script src="assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>
