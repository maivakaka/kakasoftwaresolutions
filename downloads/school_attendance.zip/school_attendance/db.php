<?php
$servername = "localhost";
$username = "root";
$password = "Maialicia@2010";
$dbname = "synergy_school";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
