<?php
include 'db.php';

$res = $conn->query("SELECT id, name,class,photo 
                     FROM students 
                     ORDER BY id DESC");

if($res->num_rows > 0){
    echo "<table class='table table-striped table-bordered'>
            <thead class='table-dark'>
              <tr><th>ID</th><th>Student</th><th>Method</th><th>Time</th></tr>
            </thead><tbody>";
    while($row = $res->fetch_assoc()){
        echo "<tr>
                <td>{$row['id']}</td>
                <td>{$row['name']}</td>
                <td>{$row['class']}</td>
                <td>{$row['photo']}</td>
              </tr>";
    }
    echo "</tbody></table>";
}else{
    echo "<div class='alert alert-info'>No attendance records found.</div>";
}
?>

