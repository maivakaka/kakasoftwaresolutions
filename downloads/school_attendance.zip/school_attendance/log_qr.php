<?php
// log_qr.php
include 'db.php';

if(isset($_POST['qr_code'])){
    $qr = $_POST['qr_code'];
    // Find student ID from QR code
    $res = $conn->query("SELECT id FROM students WHERE qr_code='$qr'");
    if($res->num_rows>0){
        $row = $res->fetch_assoc();
        $student_id = $row['id'];
        // Insert log entry
        $conn->query("INSERT INTO attendance_log (student_id, method) VALUES ($student_id, 'QR')");
        echo "Attendance logged!";
    } else {
        echo "QR code not found!";
    }
}

?>
