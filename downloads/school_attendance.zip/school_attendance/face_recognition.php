<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Face Recognition Demo</title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <script defer src="https://cdn.jsdelivr.net/npm/face-api.js"></script>
    <style>
        body { background-color: #f8f9fa; }
        h2 { color: #001f3f; }
        #inputImage { max-width: 300px; margin-top: 20px; }
        .btn-primary { background-color: #001f3f; border-color: #001f3f; }
        .btn-primary:hover { opacity: 0.9; }
    </style>
</head>
<body>
<div class="container mt-5">
    <h2>Face Recognition Demo</h2>
    <input type="file" id="imgUpload" class="form-control mt-3">
    <img id="inputImage" style="display:none">

    <script>
        async function run() {
            await faceapi.nets.ssdMobilenetv1.loadFromUri('models');
            await faceapi.nets.faceRecognitionNet.loadFromUri('models');
            await faceapi.nets.faceLandmark68Net.loadFromUri('models');

            document.getElementById('imgUpload').addEventListener('change', async function(){
                const img = document.getElementById('inputImage');
                img.src = URL.createObjectURL(this.files[0]);
                img.style.display = 'block';
                const detection = await faceapi.detectSingleFace(img).withFaceLandmarks().withFaceDescriptor();
                console.log(detection);
                alert('Face detection complete! Check console for descriptor.');
            });
        }
        run();
    </script>
</div>
<script src="assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>
