<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>School Attendance Dashboard</title>
<link rel="stylesheet" href="assets/css/bootstrap.min.css">
<script src="assets/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/qrcode.min.js"></script>
<script src="assets/js/html5-qrcode.min.js"></script>

<!-- Load face-api.js once -->
<script defer src="https://cdn.jsdelivr.net/npm/face-api.js@0.22.2/dist/face-api.min.js"></script>

<style>
body {
    background-color: #f8f9fa;
}
#sidebar {
    background-color: #001f3f;
    min-height: 100vh;
}
#sidebar .nav-link {
    color: #ff851b;
    margin-bottom: 10px;
}
#sidebar .nav-link:hover {
    color: #fff;
    background-color: #ff851b;
}
.modal-header {
    background-color: #001f3f;
    color: #ff851b;
}
.modal-footer .btn-primary { background-color: #001f3f; border-color: #001f3f; }
.modal-footer .btn-secondary { background-color: #ff851b; border-color: #ff851b; color: #fff; }
</style>
</head>
<body>
<div class="container-fluid">
<div class="row">
    <!-- Sidebar -->
    <div class="col-2 p-3" id="sidebar">
        <h4 class="text-center mb-4">Menu</h4>
        <div class="nav flex-column">
            <a class="nav-link btn btn-outline-light" data-bs-toggle="modal" data-bs-target="#addStudentModal">Add Student</a>
            <a class="nav-link btn btn-outline-light" data-bs-toggle="modal" data-bs-target="#addGuardianModal">Add Guardian</a>
            <a class="nav-link btn btn-outline-light" data-bs-toggle="modal" data-bs-target="#scanQRModal">Scan QR</a>
            <a class="nav-link btn btn-outline-light" data-bs-toggle="modal" data-bs-target="#faceModal">Face Recognition</a>
            <a class="nav-link btn btn-outline-light" data-bs-toggle="modal" data-bs-target="#logModal">Attendance Log</a>
        </div>
    </div>

    <!-- Main Content -->
    <div class="col-10 p-3">
        <h2 class="text-primary">School Attendance</h2>
        <p>Click the menu items on the left to perform actions.</p>
        <div class="container mt-4">
            <h3 class="text-primary">All Students</h3>
            <table class="table table-striped table-bordered table-hover">
                <thead class="table-dark">
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Class</th>
                        <th>QR Code</th>
                        <th>Guardians</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    include 'db.php';
                    $students_res = $conn->query("SELECT * FROM students ORDER BY name ASC");
                    $count = 1;
                    if($students_res->num_rows > 0){
                        while($student = $students_res->fetch_assoc()){
                            $g_res = $conn->query("SELECT name, contact FROM guardians WHERE student_id=".intval($student['id']));
                            $guardians = [];
                            if($g_res->num_rows > 0){
                                while($g = $g_res->fetch_assoc()){
                                    $guardians[] = htmlspecialchars($g['name'])." (".htmlspecialchars($g['contact']).")";
                                }
                            } else { $guardians[] = "No guardians assigned"; }
                            echo "<tr>
                                    <td>".$count."</td>
                                    <td>".htmlspecialchars($student['name'])."</td>
                                    <td>".htmlspecialchars($student['class'])."</td>
                                    <td>".htmlspecialchars($student['qr_code'])."</td>
                                    <td>".implode("<br>", $guardians)."</td>
                                  </tr>";
                            $count++;
                        }
                    } else {
                        echo "<tr><td colspan='5' class='text-center'>No students found.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</div>

<!-- Add Student Modal -->
<div class="modal fade" id="addStudentModal" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Add Student</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <?php
        include 'db.php';
        $qr_code = '';
        if(isset($_POST['add_student'])){
            $name = $_POST['name'];
            $class = $_POST['class'];
            $photo = $_FILES['photo']['name'];
            $target = "assets/uploads/".basename($photo);
            $qr_code = uniqid('STU_');
            if(move_uploaded_file($_FILES['photo']['tmp_name'], $target)){
                $stmt = $conn->prepare("INSERT INTO students (name,class,photo,qr_code) VALUES (?,?,?,?)");
                $stmt->bind_param("ssss",$name,$class,$photo,$qr_code);
                $stmt->execute();
                $stmt->close();
                echo "<div class='alert alert-success'>Student added successfully!</div>";
            }
        }
        ?>
        <form method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <label>Name:</label>
                <input type="text" name="name" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>Class:</label>
                <input type="text" name="class" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>Photo:</label>
                <input type="file" name="photo" class="form-control" required>
            </div>
            <button type="submit" name="add_student" class="btn btn-primary">Add Student</button>
        </form>
        <?php if($qr_code): ?>
        <div class="mt-3" id="studentQR"></div>
        <script>
        new QRCode(document.getElementById("studentQR"), { text: "<?php echo $qr_code; ?>", width: 128, height: 128 });
        </script>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

<!-- Add Guardian Modal -->
<div class="modal fade" id="addGuardianModal" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Add Guardian</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <?php
        if(isset($_POST['add_guardian'])){
            $student_id = $_POST['student_id'];
            $name = $_POST['g_name'];
            $relation = $_POST['relation'];
            $contact = $_POST['contact'];
            $stmt = $conn->prepare("INSERT INTO guardians (student_id,name,relation,contact) VALUES (?,?,?,?)");
            $stmt->bind_param("isss",$student_id,$name,$relation,$contact);
            $stmt->execute();
            $stmt->close();
            echo "<div class='alert alert-success'>Guardian added successfully!</div>";
        }
        $students = $conn->query("SELECT id,name FROM students");
        ?>
        <form method="POST">
            <div class="mb-3">
                <label>Select Student:</label>
                <select name="student_id" class="form-control" required>
                    <option value="">--Select--</option>
                    <?php while($row=$students->fetch_assoc()): ?>
                    <option value="<?php echo $row['id']; ?>"><?php echo $row['name']; ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="mb-3">
                <label>Guardian Name:</label>
                <input type="text" name="g_name" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>Relation:</label>
                <input type="text" name="relation" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>Contact:</label>
                <input type="text" name="contact" class="form-control" required>
            </div>
            <button type="submit" name="add_guardian" class="btn btn-primary">Add Guardian</button>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Scan QR Modal -->
<div class="modal fade" id="scanQRModal" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Scan QR</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <h6>Scan QR using Camera:</h6>
        <div id="reader" style="width:100%; max-width:400px;"></div>
        <hr>
        <h6>Scan QR from Image:</h6>
        <input type="file" id="qr_image" accept="image/*" class="form-control mb-2">
        <button type="button" id="scan_image_btn" class="btn btn-warning mb-3">Scan Image</button>
        <hr>
        <h6>Manual QR Input:</h6>
        <form method="POST">
          <input type="text" id="qr_input" name="qr_code" class="form-control" placeholder="Enter QR code string" required>
          <button type="submit" name="manual_qr" class="btn btn-primary mt-2">Save Attendance</button>
        </form>

        <?php
        if(isset($_POST['manual_qr'])){
            $qr = $_POST['qr_code'];
            $res = $conn->query("SELECT id FROM students WHERE qr_code='$qr'");
            if($res->num_rows>0){
                $row = $res->fetch_assoc();
                $student_id = $row['id'];
                $conn->query("INSERT INTO attendance_log (student_id, method) VALUES ($student_id,'Manual')");
                echo "<div class='alert alert-success mt-2'>Attendance logged successfully!</div>";
            } else {
                echo "<div class='alert alert-danger mt-2'>QR code not found!</div>";
            }
        }
        ?>
      </div>
    </div>
  </div>
</div>

<script src="https://unpkg.com/html5-qrcode" type="text/javascript"></script>
<script>
function onScanSuccess(decodedText) {
    document.getElementById('qr_input').value = decodedText;
    fetch('log_qr.php', {
        method: 'POST',
        headers: {'Content-Type':'application/x-www-form-urlencoded'},
        body: 'qr_code=' + encodeURIComponent(decodedText)
    })
    .then(res => res.text())
    .then(data => console.log(data));
}
var html5QrcodeScanner = new Html5QrcodeScanner("reader", {fps:10, qrbox:250});
html5QrcodeScanner.render(onScanSuccess);
document.getElementById('scan_image_btn').addEventListener('click', function(){
    const file = document.getElementById('qr_image').files[0];
    if(!file){ alert('Select an image'); return; }
    const qrScanner = new Html5Qrcode("reader");
    qrScanner.scanFile(file, true)
        .then(decodedText => { document.getElementById('qr_input').value = decodedText; alert('QR detected!'); })
        .catch(err => alert("QR not detected"))
        .finally(() => qrScanner.clear());
});
</script>

<!-- Face Recognition Modal -->
<div class="modal fade" id="faceModal" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Face Recognition</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <input type="file" id="imgUpload" class="form-control mt-3" disabled>
        <img id="inputImage" style="display:none; max-width:300px;" />
        <div id="faceMessage" class="mt-3"><span class='text-info'>Initializing...</span></div>
      </div>
    </div>
  </div>
</div>

<script>
window.addEventListener('DOMContentLoaded', async () => {
    const faceMessage = document.getElementById("faceMessage");
    const imgUpload = document.getElementById('imgUpload');
    const inputImage = document.getElementById('inputImage');
    let modelsLoaded = false;

    imgUpload.disabled = true;
    faceMessage.innerHTML = "<span class='text-info'>Loading AI models... please wait...</span>";

    try {
        await faceapi.nets.ssdMobilenetv1.loadFromUri('assets/models');
        await faceapi.nets.faceLandmark68Net.loadFromUri('assets/models');
        await faceapi.nets.faceRecognitionNet.loadFromUri('assets/models');

        modelsLoaded = true;
        faceMessage.innerHTML = "<span class='text-success'>Models loaded! You can now upload an image.</span>";
        imgUpload.disabled = false;
    } catch (err) {
        console.error("Error loading models:", err);
        faceMessage.innerHTML = "<span class='text-danger'>Failed to load models. Check console.</span>";
    }

    imgUpload.addEventListener('change', async () => {
        if (!modelsLoaded) { alert("Models still loading"); return; }
        inputImage.src = URL.createObjectURL(imgUpload.files[0]);
        inputImage.style.display = "block";

        inputImage.onload = async () => {
            faceMessage.innerHTML = "<span class='text-warning'>Detecting face...</span>";
            try {
                const detection = await faceapi
                    .detectSingleFace(inputImage)
                    .withFaceLandmarks()
                    .withFaceDescriptor();
                if(!detection){
                    faceMessage.innerHTML = "<span class='text-danger'>No face detected.</span>";
                    return;
                }
                console.log("Face detected:", detection);
                faceMessage.innerHTML = "<span class='text-success'>Face detected! Check console for details.</span>";
                alert("Face detected successfully!");
            } catch(err){
                console.error("Face detection error:", err);
                faceMessage.innerHTML = "<span class='text-danger'>Error detecting face. Check console.</span>";
            }
        };
    });
});
</script>

<!-- Attendance Log Modal -->
<div class="modal fade" id="logModal" tabindex="-1">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Attendance Log</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body" id="attendanceContent">
        <div class="text-center text-muted">Loading...</div>
      </div>
    </div>
  </div>
</div>

<script>
function loadAttendance(){
    fetch('attendance_table.php')
    .then(response => response.text())
    .then(data => document.getElementById('attendanceContent').innerHTML = data);
}
document.getElementById('logModal').addEventListener('show.bs.modal', loadAttendance);
</script>

</body>
</html>
