<?php
// Fetch options for dropdowns
$groups = $conn->query("SELECT * FROM student_group ORDER BY group_name ASC");
$classes = $conn->query("SELECT * FROM class ORDER BY name ASC");
$machines = $conn->query("SELECT * FROM machine_number ORDER BY number ASC");

?>

<!-- Add Student Modal -->
<div class="modal fade" id="addModal" tabindex="-1" aria-hidden="true">
<div class="modal-dialog modal-lg">
<div class="modal-content">
<form method="POST" enctype="multipart/form-data">
<div class="modal-header bg-success text-white">
<h5 class="modal-title">Add New Student</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal"></button>
</div>
<div class="modal-body">
<input type="hidden" name="add_student" value="1">

<div class="row mb-3">
<div class="col"><label>Firstname</label><input type="text" name="firstname" class="form-control" required></div>
<div class="col"><label>Surname</label><input type="text" name="surname" class="form-control" required></div>
</div>

<div class="row mb-3">
<div class="col"><label>Class</label>
<select name="grade_form" class="form-control" required>
<option value="">Select Class</option>
<?php $classes->data_seek(0); while($c = $classes->fetch_assoc()): ?>
<option value="<?= htmlspecialchars($c['name'], ENT_QUOTES) ?>"><?= htmlspecialchars($c['name'], ENT_QUOTES) ?></option>
<?php endwhile; ?>
<option value="__add_new" class="text-success">+ Add New Class</option>
</select></div>

<div class="col"><label>Gender</label>
<select name="gender" class="form-control" required>
<option value="">Select</option><option>Male</option><option>Female</option>
</select></div>
</div>

<div class="row mb-3">
<div class="col"><label>Group</label>
<select name="student_group" class="form-control">
<option value="">Select Group</option>
<?php $groups->data_seek(0); while($g = $groups->fetch_assoc()): ?>
<option value="<?= htmlspecialchars($g['group_name'], ENT_QUOTES) ?>"><?= htmlspecialchars($g['group_name'], ENT_QUOTES) ?></option>
<?php endwhile; ?>
<option value="__add_new" class="text-success">+ Add New Group</option>
</select></div>

<div class="col"><label>Machine Number</label>
<select name="machine_number" class="form-control">
<option value="">Select Machine</option>
<?php $machines->data_seek(0); while($m = $machines->fetch_assoc()): ?>
<option value="<?= htmlspecialchars($m['number'], ENT_QUOTES) ?>"><?= htmlspecialchars($m['number'], ENT_QUOTES) ?></option>
<?php endwhile; ?>
<option value="__add_new" class="text-success">+ Add New Machine</option>
</select></div>
</div>

<div class="mb-3"><label>Upload Questions</label><input type="file" name="questions" class="form-control"></div>

<div class="row mb-3">
<div class="col"><label>Mark</label><input type="number" name="mark" class="form-control"></div>
<div class="col"><label>Date</label><input type="date" name="date" class="form-control" value="<?= date('Y-m-d') ?>"></div>
</div>
</div>
<div class="modal-footer">
<button type="submit" class="btn btn-success">Save</button>
<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
</div>
</form>
</div>
</div>
</div>

<!-- Edit Student Modal -->
<div class="modal fade" id="editModal" tabindex="-1" aria-hidden="true">
<div class="modal-dialog modal-lg">
<div class="modal-content">
<form method="POST" enctype="multipart/form-data">
<div class="modal-header bg-primary text-white">
<h5 class="modal-title">Edit Student</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal"></button>
</div>
<div class="modal-body">
<input type="hidden" name="update_student" value="1">
<input type="hidden" name="edit_id" id="edit_id">
<input type="hidden" name="existing_file" id="existing_file">

<div class="row mb-3">
<div class="col"><label>Firstname</label><input type="text" name="edit_firstname" id="edit_firstname" class="form-control" required></div>
<div class="col"><label>Surname</label><input type="text" name="edit_surname" id="edit_surname" class="form-control" required></div>
</div>

<div class="row mb-3">
<div class="col"><label>Class</label>
<select name="edit_grade_form" id="edit_grade_form" class="form-control" required>
<option value="">Select Class</option>
<?php $classes->data_seek(0); while($c = $classes->fetch_assoc()): ?>
<option value="<?= htmlspecialchars($c['name'], ENT_QUOTES) ?>"><?= htmlspecialchars($c['name'], ENT_QUOTES) ?></option>
<?php endwhile; ?>
<option value="__add_new" class="text-success">+ Add New Class</option>
</select></div>

<div class="col"><label>Gender</label>
<select name="edit_gender" id="edit_gender" class="form-control" required>
<option value="">Select</option><option>Male</option><option>Female</option>
</select></div>
</div>

<div class="row mb-3">
<div class="col"><label>Group</label>
<select name="edit_student_group" id="edit_student_group" class="form-control">
<option value="">Select Group</option>
<?php $groups->data_seek(0); while($g = $groups->fetch_assoc()): ?>
<option value="<?= htmlspecialchars($g['group_name'], ENT_QUOTES) ?>"><?= htmlspecialchars($g['group_name'], ENT_QUOTES) ?></option>
<?php endwhile; ?>
<option value="__add_new" class="text-success">+ Add New Group</option>
</select></div>

<div class="col"><label>Machine Number</label>
<select name="edit_machine_number" id="edit_machine_number" class="form-control">
<option value="">Select Machine</option>
<?php $machines->data_seek(0); while($m = $machines->fetch_assoc()): ?>
<option value="<?= htmlspecialchars($m['number'], ENT_QUOTES) ?>"><?= htmlspecialchars($m['number'], ENT_QUOTES) ?></option>
<?php endwhile; ?>
<option value="__add_new" class="text-success">+ Add New Machine</option>
</select></div>
</div>

<div class="mb-3"><label>Upload Questions (Replace)</label><input type="file" name="edit_questions" class="form-control"></div>

<div class="row mb-3">
<div class="col"><label>Mark</label><input type="number" name="edit_mark" id="edit_mark" class="form-control"></div>
<div class="col"><label>Date</label><input type="date" name="edit_date" id="edit_date" class="form-control"></div>
</div>

</div>
<div class="modal-footer">
<button type="submit" class="btn btn-primary">Update</button>
<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
</div>
</form>
</div>
</div>
</div>

<!-- Delete Student Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<form method="POST">
<input type="hidden" name="delete_student" value="1">
<input type="hidden" name="delete_id" id="delete_id">
<div class="modal-header bg-danger text-white">
<h5 class="modal-title">Delete Student</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal"></button>
</div>
<div class="modal-body">
Are you sure you want to delete <strong id="delete_name"></strong>?
</div>
<div class="modal-footer">
<button type="submit" class="btn btn-danger">Yes, Delete</button>
<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
</div>
</form>
</div>
</div>
</div>



<!-- Add Modal -->
<div class="modal fade" id="addClassModal" tabindex="-1" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<form method="POST">
<div class="modal-header bg-success text-white">
<h5 class="modal-title">Add New Class</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal"></button>
</div>
<div class="modal-body">
<input type="hidden" name="add_class" value="1">
<div class="mb-3">
<label>Level</label>
<select name="level" id="add_level" class="form-control" onchange="updateNamePrefix()" required>
<option value="">Select Level</option>
<option value="Primary">Primary</option>
<option value="Secondary">Secondary</option>
</select>
</div>
<div class="mb-3">
<label>Class Name</label>
<input type="text" name="name" id="add_name" class="form-control" placeholder="e.g. Grade 3 or Form 2" required>
</div>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
<button type="submit" class="btn btn-success">Save</button>
</div>
</form>
</div>
</div>
</div>

<!-- Add Group Modal -->
<div class="modal fade" id="addGroupModal" tabindex="-1">
<div class="modal-dialog">
<div class="modal-content">
<form method="POST">
<div class="modal-header bg-success text-white">
<h5 class="modal-title">Add New Group</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal"></button>
</div>
<div class="modal-body">
<input type="hidden" name="add_group" value="1">
<input type="text" name="new_group" class="form-control" placeholder="Enter Group Name" required>
</div>
<div class="modal-footer">
<button type="submit" class="btn btn-success">Add</button>
<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
</div>
</form>
</div>
</div>
</div>

<!-- Project Modal -->
<div class="modal fade" id="projectModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content">

      <!-- Header -->
      <div class="modal-header">
        <h5 class="modal-title" id="projectTitle"></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <!-- Body -->
      <div class="modal-body">
        <p id="projectDescription" class="mb-3"></p>

        <!-- Features list (optional, auto-filled) -->
        <ul id="projectFeatures" class="ps-3">
          <!-- JS injects list items here -->
        </ul>
      </div>

      <!-- Footer -->
      <div class="modal-footer">
        <a id="projectButton" href="#" class="btn btn-primary">
          Get Started
        </a>
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
          Close
        </button>
      </div>

    </div>
  </div>
</div>

<!-- Add Machine Modal -->

<div class="modal fade" id="addMachineModal" tabindex="-1" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<form method="POST">
<div class="modal-header bg-success text-white">
<h5 class="modal-title">Add New Machine</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal"></button>
</div>
<div class="modal-body">
<input type="hidden" name="add_machine" value="1">
<div class="mb-3">
<label>Machine Number</label>
<input type="number" name="number" class="form-control" placeholder="e.g. PC-01" required>
</div>
<div class="mb-3">
<label>MAC Address</label>
<input type="text" name="mac_address" class="form-control" placeholder="e.g. 00:1A:2B:3C:4D:5E" required>
</div>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
<button type="submit" class="btn btn-success">Save</button>
</div>
</form>
</div>
</div>
</div>
<script src="assets/css/bootstrap-5.3.8-dist/js/bootstrap.bundle.min.js"></script>