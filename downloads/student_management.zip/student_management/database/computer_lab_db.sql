-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 20, 2026 at 12:01 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `computer_lab_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE `class` (
  `id` int(11) NOT NULL,
  `level` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`id`, `level`, `name`) VALUES
(9, 'Primary', 'Grade 1'),
(10, 'Primary', 'Grade 2'),
(11, 'Primary', 'Grade 3'),
(12, 'Primary', 'Grade 4'),
(13, 'Primary', 'Grade 5'),
(14, 'Primary', 'Grade 6'),
(15, 'Primary', 'Grade 7'),
(16, 'Infant', 'ECD A'),
(17, 'Infant', 'ECD B'),
(18, 'Secondary', 'Form 1'),
(19, 'Secondary', 'Form 2'),
(20, 'Secondary', 'Form 3'),
(21, 'Secondary', 'Form 4'),
(22, 'Secondary', 'Form 5'),
(23, 'Secondary', 'Form 6');

-- --------------------------------------------------------

--
-- Table structure for table `machine_number`
--

CREATE TABLE `machine_number` (
  `id` int(11) NOT NULL,
  `number` varchar(50) NOT NULL,
  `mac_address` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `machine_number`
--

INSERT INTO `machine_number` (`id`, `number`, `mac_address`) VALUES
(10, '01', '01A'),
(11, '02', '02A'),
(12, '03', '03A'),
(13, '04', '04A'),
(14, '05', '05A'),
(15, '06', '06A');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `firstname` varchar(100) DEFAULT NULL,
  `surname` varchar(100) DEFAULT NULL,
  `grade_form` varchar(50) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `student_group` varchar(50) DEFAULT NULL,
  `machine_number` varchar(50) DEFAULT NULL,
  `questions` varchar(255) DEFAULT NULL,
  `mark` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `firstname`, `surname`, `grade_form`, `gender`, `student_group`, `machine_number`, `questions`, `mark`, `date`) VALUES
(319, 'milcah', 'magaya', 'Form 6', 'Female', 'Group 1', '04', '', 0, '2026-10-20');

-- --------------------------------------------------------

--
-- Table structure for table `students1`
--

CREATE TABLE `students1` (
  `id` int(11) NOT NULL,
  `firstname` varchar(100) DEFAULT NULL,
  `surname` varchar(100) DEFAULT NULL,
  `grade_form` varchar(50) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `student_group` varchar(50) DEFAULT NULL,
  `machine_number` varchar(50) DEFAULT NULL,
  `questions` varchar(255) DEFAULT NULL,
  `mark` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students1`
--

INSERT INTO `students1` (`id`, `firstname`, `surname`, `grade_form`, `gender`, `student_group`, `machine_number`, `questions`, `mark`, `date`) VALUES
(1, 'Makanaka', 'Mugwagwa', 'Grade 3', 'Female', '2-4', '01', '', 0, '2025-10-22'),
(2, 'Udele ', 'Ushewokunze', 'Grade 3', 'Female', '2-5', '06', '', 0, '2025-10-22'),
(3, 'Deborah', 'Chabuka', 'Grade 3', 'Female', '2-5', '05', '', 0, '2025-10-22'),
(4, 'Dineo', 'Dombo', 'Grade 3', 'Female', '2-6', '05', '', 0, '2025-10-22'),
(5, 'Anashe', 'Kutyamaenza', 'Grade 3', 'Female', '2-4', '05', '', 0, '2025-10-22'),
(6, 'MakanakaIshe ', 'Chigweshe', 'Grade 3', 'Female', '2-5', '05', '', 0, '2025-10-22'),
(7, 'Angel', 'Mabhi', 'Grade 3', 'Female', '2-6', '06', '', 0, '2025-10-22'),
(8, 'Mercylin', 'Matsotso', 'Grade 3', 'Female', '2-5', '06', '', 0, '2025-10-22'),
(9, 'Jain', 'Muneka', 'Grade 3', 'Female', '2-6', '06', '', 0, '2025-10-22'),
(10, 'Heina', 'Matendere', 'Grade 3', 'Female', '2-6', '06', '', 0, '2025-10-22'),
(11, 'Trish', 'Manwa', 'Grade 3', 'Female', '2-3', '02', '', 0, '2025-10-22'),
(12, 'Precious', 'Goredema', 'Grade 3', 'Female', '2-6', '05', '', 0, '2025-10-22'),
(13, 'Sharon', 'Munemo', 'Grade 3', 'Female', '2-5', '05', '', 0, '2025-10-22'),
(14, 'Eugine', 'Muganhu', 'Grade 3', 'Female', '2-6', '06', '', 0, '2025-10-22'),
(15, 'Alexis', 'Simbi', 'Grade 3', 'Female', '2-6', '06', '', 0, '2025-10-22'),
(16, 'Laicy', 'Karuwenga', 'Grade 3', 'Female', '2-5', '06', '', 0, '2025-10-22'),
(17, 'Jaylin', 'Gavi', 'Grade 3', 'Female', '2-6', '06', '', 0, '2025-10-22'),
(18, 'Ashely', 'Simbi', 'Grade 3', 'Female', '2-6', '06', '', 0, '2025-10-22'),
(19, 'Angel', 'Taderera', 'Grade 3', 'Female', '2-6', '06', '', 0, '2025-10-22'),
(20, 'Sasha', 'Madhara', 'Grade 3', 'Female', '2-5', '06', '', 0, '2025-10-22'),
(21, 'Kiara', 'Chipunza', 'Grade 3', 'Female', '1-3', '05', '', 0, '2025-10-22');

-- --------------------------------------------------------

--
-- Table structure for table `student_group`
--

CREATE TABLE `student_group` (
  `id` int(11) NOT NULL,
  `group_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_group`
--

INSERT INTO `student_group` (`id`, `group_name`) VALUES
(15, 'Group 2'),
(16, 'Group 1');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`) VALUES
(1, 'admin', '$2y$10$aVCaKsyHpwVO81mXxVtYqefLnzknmIQTbdZ2ohCIdWnCzKrHQMA6K', 'ICT Teacher'),
(3, 'sadmin', '12345', 'Admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `machine_number`
--
ALTER TABLE `machine_number`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students1`
--
ALTER TABLE `students1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_group`
--
ALTER TABLE `student_group`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `class`
--
ALTER TABLE `class`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `machine_number`
--
ALTER TABLE `machine_number`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=320;

--
-- AUTO_INCREMENT for table `students1`
--
ALTER TABLE `students1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `student_group`
--
ALTER TABLE `student_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
