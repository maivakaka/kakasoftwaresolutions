<?php
include 'db.php';

// Initialize error messages
$add_error = '';
$edit_error = '';

// Handle Add Class
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_class'])) {
    $level = $_POST['level'];
    $name = trim($_POST['name']);

    $stmt = $conn->prepare("SELECT * FROM class WHERE level = ? AND name = ?");
    $stmt->bind_param("ss", $level, $name);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($res->num_rows > 0) {
        $add_error = "This class already exists.";
    } else {
        $insert = $conn->prepare("INSERT INTO class (level, name) VALUES (?, ?)");
        $insert->bind_param("ss", $level, $name);
        if ($insert->execute()) {
            header("Location: /computer-lab/classes");
            exit();
        } else {
            $add_error = "Error: " . $insert->error;
        }
        $insert->close();
    }
    $stmt->close();
}

// Handle Update Class
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_class'])) {
    $id = intval($_POST['edit_id']);
    $level = $_POST['edit_level'];
    $name = trim($_POST['edit_name']);

    $stmt = $conn->prepare("SELECT * FROM class WHERE level = ? AND name = ? AND id != ?");
    $stmt->bind_param("ssi", $level, $name, $id);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($res->num_rows > 0) {
        $edit_error = "Another class with this name already exists.";
    } else {
        $update = $conn->prepare("UPDATE class SET level = ?, name = ? WHERE id = ?");
        $update->bind_param("ssi", $level, $name, $id);
        if ($update->execute()) {
            header("Location: /computer-lab/classes");
            exit();
        } else {
            $edit_error = "Error: " . $update->error;
        }
        $update->close();
    }
    $stmt->close();
}

// Handle Delete Class
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_class'])) {
    $id = intval($_POST['delete_id']);
    $stmt = $conn->prepare("DELETE FROM class WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
    header("Location: /computer-lab/classes");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Class Management</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/css/bootstrap-5.3.8-dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/dataTables.bootstrap5.min.css">
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/dataTables.bootstrap5.min.js"></script>

<style>
body { background-color: #f8f9fa; display: flex; }
.sidebar { width: 250px; height: 100vh; background-color: #001f3f; color: white; padding: 20px; position: sticky; top: 0; }
.sidebar a { color: white; text-decoration: none; display: block; padding: 10px 15px; margin-bottom: 10px; border-radius: 8px; transition: 0.3s; }
.sidebar a:hover, .sidebar a.active { background-color: #ff851b; color: #001f3f; font-weight: bold; }
.sidebar .logout-btn { background-color: #ff4136; color: white; text-align: center; padding: 10px; border-radius: 8px; text-decoration: none; display: block; }
.sidebar .logout-btn:hover { background-color: #ff6347; }
.main-content { flex-grow: 1; padding: 30px; }
.my_btn { background-color: #ff8c00; }
.my_btn2 { background-color: #001f3f; color:white;}
</style>
<script>
function fillEditModal(id, level, name) {
    document.getElementById('edit_id').value = id;
    document.getElementById('edit_level').value = level;
    document.getElementById('edit_name').value = name;
}

function fillDeleteModal(id, name) {
    document.getElementById('delete_id').value = id;
    document.getElementById('delete_name').textContent = name;
}

function updateNamePrefix() {
    const level = document.getElementById('add_level');
    const nameInput = document.getElementById('add_name');
    if (!level || !nameInput) return;
    if (level.value === 'Primary') {
        nameInput.value = 'Grade ';
        nameInput.focus();
    } else if (level.value === 'Secondary') {
        nameInput.value = 'Form ';
        nameInput.focus();
    } else if (level.value === 'Infant') {
        nameInput.value = 'ECD ';
        nameInput.focus();
    } 
    else {
        nameInput.value = '';
    }
}
</script>
</head>
<body>
<?php include 'sidebar.php'; ?>

<div class="main-content">
<h3 class="text-center mb-4 text-dark">Class Management</h3>

<?php
// Display Add/Edit error messages above modals
if ($add_error) {
    echo "<div class='alert alert-warning'>{$add_error}</div>";
}
if ($edit_error) {
    echo "<div class='alert alert-warning'>{$edit_error}</div>";
}
?>

<div class="row mb-3 align-items-center">
  <div class="col-md-4">
    <input type="text" id="tableSearch" class="form-control" placeholder="🔍 Search classes...">
  </div>
  <div class="col-md-4 text-end ms-auto">
    <button class="btn my_btn" data-bs-toggle="modal" data-bs-target="#addModal">+ Add New Class</button>
  </div>
</div>

<div class="card mb-4 shadow-sm border-0">
    <div class="card-body">
        <table id="classTable" class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Level</th>
                    <th>Name</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            <?php
            $result = $conn->query("SELECT * FROM class ORDER BY id DESC");
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $id = $row['id'];
                    $level = htmlspecialchars($row['level'], ENT_QUOTES);
                    $name = htmlspecialchars($row['name'], ENT_QUOTES);
                    echo "<tr>
                        <td>{$id}</td>
                        <td>{$level}</td>
                        <td>{$name}</td>
                        <td>
                            <div class='d-flex gap-2 w-100'>
                                <button class='btn btn-sm my_btn2 flex-fill' data-bs-toggle='modal' data-bs-target='#editModal'
                                    onclick=\"fillEditModal('{$id}', '{$level}', '{$name}')\">Edit</button>
                                <button class='btn btn-sm btn-danger flex-fill' data-bs-toggle='modal' data-bs-target='#deleteModal'
                                    onclick=\"fillDeleteModal('{$id}', '{$name}')\">Delete</button>
                            </div>
                        </td>
                    </tr>";
                }
            } else {
                echo "<tr><td colspan='4' class='text-center'>No records found</td></tr>";
            }
            ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Add Modal -->
<div class="modal fade" id="addModal" tabindex="-1" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<form method="POST">
<div class="modal-header bg-success text-white">
<h5 class="modal-title">Add New Class</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal"></button>
</div>
<div class="modal-body">
<input type="hidden" name="add_class" value="1">
<div class="mb-3">
<label>Level</label>
<select name="level" id="add_level" class="form-control" onchange="updateNamePrefix()" required>
<option value="">Select Level</option>
<option value="Infant">Infant</option>
<option value="Primary">Primary</option>
<option value="Secondary">Secondary</option>
</select>
</div>
<div class="mb-3">
<label>Class Name</label>
<input type="text" name="name" id="add_name" class="form-control" placeholder="e.g. Grade 3 or Form 2" required>
</div>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
<button type="submit" class="btn btn-success">Save</button>
</div>
</form>
</div>
</div>
</div>

<!-- Edit Modal -->
<div class="modal fade" id="editModal" tabindex="-1" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<form method="POST">
<div class="modal-header bg-primary text-white">
<h5 class="modal-title">Edit Class</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal"></button>
</div>
<div class="modal-body">
<input type="hidden" name="edit_id" id="edit_id">
<div class="mb-3">
<label>Level</label>
<select name="edit_level" id="edit_level" class="form-control" required>
<option value="">Select Level</option>
<option value="Primary">Primary</option>
<option value="Secondary">Secondary</option>
</select>
</div>
<div class="mb-3">
<label>Class Name</label>
<input type="text" name="edit_name" id="edit_name" class="form-control" required>
</div>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
<button type="submit" name="update_class" class="btn btn-primary">Update</button>
</div>
</form>
</div>
</div>
</div>

<!-- Delete Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<form method="POST">
<input type="hidden" name="delete_class" value="1">
<input type="hidden" name="delete_id" id="delete_id">
<div class="modal-header bg-danger text-white">
<h5 class="modal-title">Delete Class</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal"></button>
</div>
<div class="modal-body">
Are you sure you want to delete <strong id="delete_name"></strong>?
</div>
<div class="modal-footer">
<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
<button type="submit" class="btn btn-danger">Yes, Delete</button>
</div>
</form>
</div>
</div>
</div>

</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
document.getElementById("tableSearch").addEventListener("keyup", function() {
  var input = this.value.toLowerCase();
  var rows = document.querySelectorAll("table tbody tr");

  rows.forEach(function(row) {
    let text = row.textContent.toLowerCase();
    row.style.display = text.includes(input) ? "" : "none";
  });
});
</script>

<script>
$(document).ready(function() {
    $('#classTable').DataTable({
        "order": [], // No default ordering
        "columnDefs": [
            { "orderable": false, "targets": -1 } // Disable sorting for Action column
        ]
    });
});
</script>

<script src="assets/css/bootstrap-5.3.8-dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
