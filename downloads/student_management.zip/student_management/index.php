<?php
include 'db.php';

// Fetch counts
$student_count = $conn->query("SELECT COUNT(*) AS total FROM students")->fetch_assoc()['total'];
$class_count   = $conn->query("SELECT COUNT(*) AS total FROM class")->fetch_assoc()['total'];
$group_count   = $conn->query("SELECT COUNT(*) AS total FROM student_group")->fetch_assoc()['total'];
$machine_count = $conn->query("SELECT COUNT(*) AS total FROM machine_number")->fetch_assoc()['total'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Dashboard - Computer Lab System now</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/css/bootstrap-5.3.8-dist/css/bootstrap.min.css" rel="stylesheet">
 
  <link rel="stylesheet" href="assets/css/style.css">
  <style>
    body {
      background-color: #f8f9fa;
      font-family: "Poppins", sans-serif;
    }

    /* Sidebar */
    .sidebar {
      background-color: #032B44;
      height: 100vh;
      padding: 20px;
      color: #fff;
      position: fixed;
      width: 220px;
    }
    .sidebar a {
      display: block;
      color: white;
      padding: 12px;
      margin: 6px 0;
      text-decoration: none;
      border-radius: 8px;
      transition: background 0.3s;
    }
    .sidebar a:hover,
    .sidebar a.active {
      background-color: #ff8c00;
      color: #fff;
    }
    .logout-btn {
      background-color: #dc3545 !important;
      color: #fff !important;
    }

    /* Main content */
    .main-content {
      margin-left: 240px;
      padding: 40px;
    }

    /* Base Card Style */
    .dashboard-card {
      color: white;
      border: none;
      border-radius: 15px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
      transition: transform 0.2s, box-shadow 0.2s;
      text-align: center;
      padding: 35px 20px;
      cursor: pointer;
    }
    .dashboard-card:hover {
      transform: translateY(-6px);
      box-shadow: 0 6px 18px rgba(0,0,0,0.2);
    }
    .dashboard-card h3 {
      font-size: 1.4rem;
      margin-top: 10px;
      color: #fff;
    }
    .dashboard-card .count {
      font-size: 2.8rem;
      font-weight: bold;
      color: #fff;
    }

    /* Individual Colors */
    .card-orange {
      background: #ff8c00;
    }
    .card-orange:hover {
      background: #ffae42;
    }

    .card-navy {
      background: #032B44;
    }
    .card-navy:hover {
      background: #064a74;
    }
  </style>
</head>

<body>
<div class="container-fluid">
  <div class="row">
    <!-- Sidebar -->
    <div class="col-md-3 col-lg-2 p-0">
      <?php include 'sidebar.php'; ?>
    </div>

    <!-- Main Content -->
    <div class="col-md-9 col-lg-10 main-content">
      <h2 class="text-center mb-5 mt-3 text-dark">💻 Computer Lab Dashboard</h2>

      <div class="row g-4 justify-content-center">
        <!-- Students (Orange) -->
        <div class="col-md-3 col-sm-6">
          <div class="dashboard-card card-orange" onclick="location.href='add_student.php'">
            <div>👩‍🎓</div>
            <div class="count"><?php echo $student_count; ?></div>
            <h3>Students</h3>
          </div>
        </div>

        <!-- Classes (Navy) -->
        <div class="col-md-3 col-sm-6">
          <div class="dashboard-card card-navy" onclick="location.href='add_class.php'">
            <div>🏫</div>
            <div class="count"><?php echo $class_count; ?></div>
            <h3>Classes</h3>
          </div>
        </div>

        <!-- Groups (Orange) -->
        <div class="col-md-3 col-sm-6">
          <div class="dashboard-card card-orange" onclick="location.href='add_group.php'">
            <div>👥</div>
            <div class="count"><?php echo $group_count; ?></div>
            <h3>Groups</h3>
          </div>
        </div>

        <!-- Machines (Navy) -->
        <div class="col-md-3 col-sm-6">
          <div class="dashboard-card card-navy" onclick="location.href='add_machine.php'">
            <div>💻</div>
            <div class="count"><?php echo $machine_count; ?></div>
            <h3>Machines</h3>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script src="assets/css/bootstrap-5.3.8-dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
