<?php
//include '../computer-lab/db.php';
include '../db.php';

// Fetch counts
$student_count = $conn->query("SELECT COUNT(*) AS total FROM students")->fetch_assoc()['total'];
$class_count   = $conn->query("SELECT COUNT(*) AS total FROM class")->fetch_assoc()['total'];
$group_count   = $conn->query("SELECT COUNT(*) AS total FROM student_group")->fetch_assoc()['total'];
$machine_count = $conn->query("SELECT COUNT(*) AS total FROM machine_number")->fetch_assoc()['total'];

// Fetch counts
$queryF1=mysqli_query($conn,"Select * from students WHERE grade_form='Form 1'");
$totalF1=mysqli_num_rows($queryF1);

$queryF2=mysqli_query($conn,"Select * from students WHERE grade_form='Form 2'");
$totalF2=mysqli_num_rows($queryF2);

$queryF5=mysqli_query($conn,"Select * from students WHERE grade_form='Form 5'");
$totalF5=mysqli_num_rows($queryF5);

$queryF6=mysqli_query($conn,"Select * from students WHERE grade_form='Form 6'");
$totalF6=mysqli_num_rows($queryF6);

$queryF3=mysqli_query($conn,"Select * from students WHERE grade_form='Form 3'");
$totalF3=mysqli_num_rows($queryF3);

$queryF4=mysqli_query($conn,"Select * from students WHERE grade_form='Form 4'");
$totalF4=mysqli_num_rows($queryF4);
                            
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Dashboard - Secondary Classes</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="assets/css/style.css">
  <link href="../assets/css/bootstrap-5.3.8-dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #f8f9fa;
      font-family: "Poppins", sans-serif;
    }

    /* Sidebar */
    .sidebar {
      background-color: #032B44;
      height: 100vh;
      padding: 20px;
      color: #fff;
      position: fixed;
      width: 220px;
    }
    .sidebar a {
      display: block;
      color: white;
      padding: 12px;
      margin: 6px 0;
      text-decoration: none;
      border-radius: 8px;
      transition: background 0.3s;
    }
    .sidebar a:hover,
    .sidebar a.active {
      background-color: #ff8c00;
      color: #fff;
    }
    .logout-btn {
      background-color: #dc3545 !important;
      color: #fff !important;
    }

    /* Main content */
    .main-content {
      margin-left: 240px;
      padding: 40px;
    }

    /* Base Card Style */
    .dashboard-card {
      color: white;
      border: none;
      border-radius: 15px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
      transition: transform 0.2s, box-shadow 0.2s;
      text-align: center;
      padding: 35px 20px;
      cursor: pointer;
    }
    .dashboard-card:hover {
      transform: translateY(-6px);
      box-shadow: 0 6px 18px rgba(0,0,0,0.2);
    }
    .dashboard-card h3 {
      font-size: 1.4rem;
      margin-top: 10px;
      color: #fff;
    }
    .dashboard-card .count {
      font-size: 2.8rem;
      font-weight: bold;
      color: #fff;
    }

    /* Individual Colors */
    .card-orange {
      background: #ff8c00;
    }
    .card-orange:hover {
      background: #ffae42;
    }

    .card-navy {
      background: #032B44;
    }
    .card-navy:hover {
      background: #064a74;
    }
  </style>
</head>

<body>
<div class="container-fluid">
  <div class="row">
    <!-- Sidebar -->
    <div class="col-md-3 col-lg-2 p-0">
      <?php include 'sidebar.php'; ?>
    </div>

    <!-- Main Content -->
    <div class="col-md-9 col-lg-10 main-content">
      <h2 class="text-center mb-5 mt-3 text-dark">💻 All Secondary Reports</h2>

      <div class="row g-4 justify-content-center">
        <!-- Students (Orange) -->
        <div class="col-md-3 col-sm-6">
          <div class="dashboard-card card-orange" onclick="location.href='/student_management/reports/secondary/form1'">
            <div>👩‍🎓</div>
            <div class="count"><?php echo $totalF1; ?></div>
            <h3>Form 1</h3>
          </div>
        </div>

        <!-- Classes (Navy) -->
        <div class="col-md-3 col-sm-6">
          <div class="dashboard-card card-navy" onclick="location.href='/student_management/reports/secondary/form2'">
            <div>🏫</div>
            <div class="count"><?php echo $totalF2; ?></div>
            <h3>Form 2</h3>
          </div>
        </div>

        <!-- Groups (Orange) -->
        <div class="col-md-3 col-sm-6">
          <div class="dashboard-card card-orange" onclick="location.href='/student_management/reports/secondary/form3'">
            <div>👥</div>
            <div class="count"><?php echo $totalF3; ?></div>
            <h3>Form 3</h3>
          </div>
        </div>

        <!-- Machines (Navy) -->
        <div class="col-md-3 col-sm-6">
          <div class="dashboard-card card-navy" onclick="location.href='/student_management/reports/secondary/form4'">
            <div>💻</div>
            <div class="count"><?php echo $totalF4; ?></div>
            <h3>Form 4</h3>
          </div>
        </div>

 <!-- Machines (Navy) -->
        <div class="col-md-3 col-sm-6">
          <div class="dashboard-card card-navy" onclick="location.href='/student_management/reports/secondary/form5'">
            <div>💻</div>
            <div class="count"><?php echo $totalF5; ?></div>
            <h3>Form 5</h3>
          </div>
        </div>

         <!-- Machines (Navy) -->
        <div class="col-md-3 col-sm-6">
          <div class="dashboard-card card-orange" onclick="location.href='/student_management/reports/secondary/form6'">
            <div>💻</div>
            <div class="count"><?php echo $totalF6; ?></div>
            <h3>Form 6</h3>
          </div>
        </div>

       

      </div>
    </div>
  </div>
</div>
<script src="assets/css/bootstrap-5.3.8-dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
