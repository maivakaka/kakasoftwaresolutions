<?php
$currentPage = basename($_SERVER['PHP_SELF']);
?>

<div class="sidebar">
  <h4 class="text-center mb-4">💻 Lab System</h4>

  <a href="/student_management/home" class="<?= $currentPage == 'index.php' ? 'active' : '' ?>">Dashboard</a>
  <a href="/student_management/reports/pri_reports" class="<?= $currentPage == 'primary.php' ? 'active' : '' ?>">Primary Reports</a>
  <a href="/student_management/reports/secondary_reports" class="<?= $currentPage == 'sec.php' ? 'active' : '' ?>">Secondary Reports</a>
  

  <a href="/student_management/logs" class="<?= $currentPage == 'logout.php' ? 'active' : '' ?> logout-btn mt-4" >Logout</a>
</div>
