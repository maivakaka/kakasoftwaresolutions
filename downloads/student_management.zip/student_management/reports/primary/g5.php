<?php
//include 'db.php';
include '../../db.php';
// Fetch options for dropdowns
$groups = $conn->query("SELECT * FROM student_group ORDER BY group_name ASC");
$classes = $conn->query("SELECT * FROM class ORDER BY name ASC");
$machines = $conn->query("SELECT * FROM machine_number ORDER BY number ASC");

// ======================
// Handle Add, Update, Delete
// ======================

// Add Student
if(isset($_POST['add_student'])){
    $firstname = $_POST['firstname'];
    $surname = $_POST['surname'];
    $grade_form = $_POST['grade_form'];
    $gender = $_POST['gender'];
    $student_group = $_POST['student_group'];
    $machine_number = $_POST['machine_number'];
    $mark = $_POST['mark'];
    $date = $_POST['date'];

    // Handle file upload
    $questions = '';
    if(isset($_FILES['questions']) && $_FILES['questions']['error'] == 0){
        $targetDir = "uploads/";
        if(!is_dir($targetDir)) mkdir($targetDir, 0777, true);
        $filename = basename($_FILES['questions']['name']);
        $targetFile = $targetDir . time() . "_" . $filename;
        if(move_uploaded_file($_FILES['questions']['tmp_name'], $targetFile)){
            $questions = $targetFile;
        }
    }

    $stmt = $conn->prepare("INSERT INTO students (firstname, surname, grade_form, gender, student_group, machine_number, mark, date, questions) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssssiss", $firstname, $surname, $grade_form, $gender, $student_group, $machine_number, $mark, $date, $questions);
    $stmt->execute();
    $stmt->close();
    header("Location: ".$_SERVER['PHP_SELF']);
    exit;
}

// Update Student
if(isset($_POST['update_student'])){
    $id = $_POST['edit_id'];
    $firstname = $_POST['edit_firstname'];
    $surname = $_POST['edit_surname'];
    $grade_form = $_POST['edit_grade_form'];
    $gender = $_POST['edit_gender'];
    $student_group = $_POST['edit_student_group'];
    $machine_number = $_POST['edit_machine_number'];
    $mark = $_POST['edit_mark'];
    $date = $_POST['edit_date'];
    $existing_file = $_POST['existing_file'];

    // Handle file upload
    $questions = $existing_file;
    if(isset($_FILES['edit_questions']) && $_FILES['edit_questions']['error'] == 0){
        $targetDir = "uploads/";
        if(!is_dir($targetDir)) mkdir($targetDir, 0777, true);
        $filename = basename($_FILES['edit_questions']['name']);
        $targetFile = $targetDir . time() . "_" . $filename;
        if(move_uploaded_file($_FILES['edit_questions']['tmp_name'], $targetFile)){
            $questions = $targetFile;
        }
    }

    $stmt = $conn->prepare("UPDATE students SET firstname=?, surname=?, grade_form=?, gender=?, student_group=?, machine_number=?, mark=?, date=?, questions=? WHERE id=?");
    $stmt->bind_param("ssssssissi", $firstname, $surname, $grade_form, $gender, $student_group, $machine_number, $mark, $date, $questions, $id);
    $stmt->execute();
    $stmt->close();
    header("Location: ".$_SERVER['PHP_SELF']);
    exit;
}

// Delete Student
if(isset($_POST['delete_student'])){
    $id = $_POST['delete_id'];
    $conn->query("DELETE FROM students WHERE id='$id'");
    header("Location: ".$_SERVER['PHP_SELF']);
    exit;
}

// Add Class
if(isset($_POST['name'])){
    $new_class = $_POST['name'];
    $stmt = $conn->prepare("INSERT INTO class (name) VALUES (?)");
    $stmt->bind_param("s",$new_class);
    $stmt->execute();
    $stmt->close();
    header("Location: ".$_SERVER['PHP_SELF']);
    exit;
}

// Add Group
if(isset($_POST['add_group'])){
    $new_group = $_POST['new_group'];
    $stmt = $conn->prepare("INSERT INTO student_group (group_name) VALUES (?)");
    $stmt->bind_param("s",$new_group);
    $stmt->execute();
    $stmt->close();
    header("Location: ".$_SERVER['PHP_SELF']);
    exit;
}

// Add Machine
// Add Machine
if(isset($_POST['add_machine'])){
    $machine_number = $_POST['number'];       // from modal input "number"
    $mac_address   = $_POST['mac_address'];   // from modal input "mac_address"

    $stmt = $conn->prepare("INSERT INTO machine_number (number, mac_address) VALUES (?, ?)");
    $stmt->bind_param("ss", $machine_number, $mac_address);
    $stmt->execute();
    $stmt->close();

    header("Location: ".$_SERVER['PHP_SELF']);
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Student Management</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="../../assets/css/bootstrap-5.3.8-dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/dataTables.bootstrap5.min.css">
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/dataTables.bootstrap5.min.js"></script>

<script>function updateNamePrefix() {
    const level = document.getElementById('add_level');
    const nameInput = document.getElementById('add_name');
    if (!level || !nameInput) return;
    if (level.value === 'Primary') {
        nameInput.value = 'Grade ';
        nameInput.focus();
    } else if (level.value === 'Secondary') {
        nameInput.value = 'Form ';
        nameInput.focus();
    } else {
        nameInput.value = '';
    }
}</script>
<style>
body { background-color: #f8f9fa; display: flex; margin:0; }
.sidebar { width: 250px; height: 100vh; background-color: #001f3f; color:white; padding:20px; position:sticky; top:0; }
.sidebar a { color:white; text-decoration:none; display:block; padding:10px 15px; margin-bottom:10px; border-radius:8px; transition:0.3s;}
.sidebar a:hover, .sidebar a.active { background-color:#ff851b; color:#001f3f; font-weight:bold; }
.sidebar .logout-btn { background-color:#ff4136; color:white; text-align:center; padding:10px; border-radius:8px; text-decoration:none; display:block; }
.sidebar .logout-btn:hover { background-color:#ff6347; }
.main-content { flex-grow:1; padding:30px; }
.my_btn { background-color: #ff8c00; }
.my_btn2 { background-color: #001f3f; color:white;}
.my_btn:hover {
    background-color: #ff8000; /* Orange hover */
    color: white;
}
</style>
<script>
function fillEditModal(id, firstname, surname, grade_form, gender, student_group, machine_number, mark, date, questions){
    document.getElementById('edit_id').value = id;
    document.getElementById('edit_firstname').value = firstname;
    document.getElementById('edit_surname').value = surname;
    document.getElementById('edit_grade_form').value = grade_form;
    document.getElementById('edit_gender').value = gender;
    document.getElementById('edit_student_group').value = student_group;
    document.getElementById('edit_machine_number').value = machine_number;
    document.getElementById('edit_mark').value = mark;
    document.getElementById('edit_date').value = date;
    document.getElementById('existing_file').value = questions;
}
function fillDeleteModal(id, name){
    document.getElementById('delete_id').value = id;
    document.getElementById('delete_name').textContent = name;
}

// Handle "Add New" in dropdowns
document.addEventListener('DOMContentLoaded', function(){
    ['grade_form','student_group','machine_number'].forEach(function(name){
        document.querySelectorAll(`select[name="${name}"]`).forEach(function(sel){
            sel.addEventListener('change', function(){
                if(this.value === '__add_new'){
                    let modalId = '';
                    if(name==='grade_form') modalId='addClassModal';
                    if(name==='student_group') modalId='addGroupModal';
                    if(name==='machine_number') modalId='addMachineModal';
                    new bootstrap.Modal(document.getElementById(modalId)).show();
                    this.value = '';
                }
            });
        });
    });
});
</script>
</head>
<body>
<?php include '../sidebar.php'; ?>

<div class="main-content">

<h3 class="text-center mb-4 text-dark">Grade 5</h3>
<div class="row mb-3 align-items-center">
  <div class="col-md-4">
    <input type="text" id="tableSearch" class="form-control" placeholder="🔍 Search students...">
  </div>
  <div class="col-md-4 text-end ms-auto">
    <button class="btn my_btn" data-bs-toggle="modal" data-bs-target="#addModal">Export to pdf</button>
  </div>
</div>


<div class="card mb-4 shadow-sm border-0">
<div class="card-body">
<table id="studentsTable" class="table table-bordered table-striped">
<thead>
<tr>
<th>Firstname</th><th>Surname</th><th>Class</th><th>Gender</th><th>Group</th><th>Machine</th><th>Action</th>
</tr>
</thead>
<tbody>
<?php
$res = $conn->query("Select * from students WHERE grade_form='Grade 5'");
if($res->num_rows > 0){
    while($row = $res->fetch_assoc()){
        $id = $row['id'];
        $firstname = htmlspecialchars($row['firstname'], ENT_QUOTES);
        $surname = htmlspecialchars($row['surname'], ENT_QUOTES);
        $grade_form = htmlspecialchars($row['grade_form'], ENT_QUOTES);
        $gender = $row['gender'];
        $student_group = htmlspecialchars($row['student_group'], ENT_QUOTES);
        $machine_number = htmlspecialchars($row['machine_number'], ENT_QUOTES);
        $mark = $row['mark'];
        $date = $row['date'];
        $questions = $row['questions'];
        $qlink = $questions ? "<a href='$questions' target='_blank'>View</a>" : "";

        echo "<tr>
        
        <td>$firstname</td>
        <td>$surname</td>
        <td>$grade_form</td>
        <td>$gender</td>
        <td>$student_group</td>
        <td>$machine_number</td>
       
        <td>
        <button class='btn btn-sm my_btn2' data-bs-toggle='modal' data-bs-target='#editModal' 
            onclick=\"fillEditModal('$id','$firstname','$surname','$grade_form','$gender','$student_group','$machine_number','$mark','$date','$questions')\">Edit</button>
        <button class='btn btn-sm btn-danger' data-bs-toggle='modal' data-bs-target='#deleteModal'
            onclick=\"fillDeleteModal('$id','$firstname $surname')\">Delete</button>
        </td></tr>";
    }
} else { echo "<tr><td colspan='11' class='text-center'>No students found</td></tr>"; }
?>
</tbody>
</table>
</div>
</div>

<!-- Add Student Modal -->
<?php include '../../student_modals.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</div>
<script>
document.addEventListener("DOMContentLoaded", function() {
    // Handle dynamic modal opening from dropdowns
    document.querySelectorAll("select").forEach(select => {
        select.addEventListener("change", function() {
            if (this.value === "__add_new") {
                // Determine which modal to show
                if (this.name.includes("grade_form") || this.name.includes("edit_grade_form")) {
                    new bootstrap.Modal(document.getElementById("addClassModal")).show();
                } else if (this.name.includes("student_group") || this.name.includes("edit_student_group")) {
                    new bootstrap.Modal(document.getElementById("addGroupModal")).show();
                } else if (this.name.includes("machine_number") || this.name.includes("edit_machine_number")) {
                    new bootstrap.Modal(document.getElementById("addMachineModal")).show();
                }
                // Reset dropdown back to default
                this.value = "";
            }
        });
    });
});
</script>

<script>
document.getElementById("tableSearch").addEventListener("keyup", function() {
  var input = this.value.toLowerCase();
  var rows = document.querySelectorAll("table tbody tr");

  rows.forEach(function(row) {
    let text = row.textContent.toLowerCase();
    row.style.display = text.includes(input) ? "" : "none";
  });
});
</script>

<script src="../assets/css/bootstrap-5.3.8-dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
