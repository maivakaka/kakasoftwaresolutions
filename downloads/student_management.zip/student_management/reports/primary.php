<?php
//include '../computer-lab/db.php';
include '../db.php';

// Fetch counts
$query2=mysqli_query($conn,"Select * from students WHERE grade_form='Grade 4'");
$totalGrade4=mysqli_num_rows($query2);

$query1=mysqli_query($conn,"Select * from students WHERE grade_form='Grade 1'");
$totalGrade1=mysqli_num_rows($query1);

$query3=mysqli_query($conn,"Select * from students WHERE grade_form='Grade 3'");
$totalGrade3=mysqli_num_rows($query3);

$query4=mysqli_query($conn,"Select * from students WHERE grade_form='Grade 2'");
$totalGrade2=mysqli_num_rows($query4);

$query5=mysqli_query($conn,"Select * from students WHERE grade_form='Grade 5'");
$totalGrade5=mysqli_num_rows($query5);

$query6=mysqli_query($conn,"Select * from students WHERE grade_form='Grade 6'");
$totalGrade6=mysqli_num_rows($query6);

$query7=mysqli_query($conn,"Select * from students WHERE grade_form='Grade 7'");
$totalGrade7=mysqli_num_rows($query7);

$queryA=mysqli_query($conn,"Select * from students WHERE grade_form='ECD A'");
$totalECDA=mysqli_num_rows($queryA);

$queryB=mysqli_query($conn,"Select * from students WHERE grade_form='ECD B'");
$totalECDB=mysqli_num_rows($queryB);
                            
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Dashboard - Primary Classes</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="assets/css/style.css">
  <link href="../assets/css/bootstrap-5.3.8-dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #f8f9fa;
      font-family: "Poppins", sans-serif;
    }

    /* Sidebar */
    .sidebar {
      background-color: #032B44;
      height: 100vh;
      padding: 20px;
      color: #fff;
      position: fixed;
      width: 220px;
    }
    .sidebar a {
      display: block;
      color: white;
      padding: 12px;
      margin: 6px 0;
      text-decoration: none;
      border-radius: 8px;
      transition: background 0.3s;
    }
    .sidebar a:hover,
    .sidebar a.active {
      background-color: #ff8c00;
      color: #fff;
    }
    .logout-btn {
      background-color: #dc3545 !important;
      color: #fff !important;
    }

    /* Main content */
    .main-content {
      margin-left: 240px;
      padding: 40px;
    }

    /* Base Card Style */
    .dashboard-card {
      color: white;
      border: none;
      border-radius: 15px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
      transition: transform 0.2s, box-shadow 0.2s;
      text-align: center;
      padding: 35px 20px;
      cursor: pointer;
    }
    .dashboard-card:hover {
      transform: translateY(-6px);
      box-shadow: 0 6px 18px rgba(0,0,0,0.2);
    }
    .dashboard-card h3 {
      font-size: 1.4rem;
      margin-top: 10px;
      color: #fff;
    }
    .dashboard-card .count {
      font-size: 2.8rem;
      font-weight: bold;
      color: #fff;
    }

    /* Individual Colors */
    .card-orange {
      background: #ff8c00;
    }
    .card-orange:hover {
      background: #ffae42;
    }

    .card-navy {
      background: #032B44;
    }
    .card-navy:hover {
      background: #064a74;
    }
  </style>
</head>

<body>
<div class="container-fluid">
  <div class="row">
    <!-- Sidebar -->
    <div class="col-md-3 col-lg-2 p-0">
      <?php include 'sidebar.php'; ?>
    </div>

    <!-- Main Content -->
    <div class="col-md-9 col-lg-10 main-content">
      <h2 class="text-center mb-5 mt-3 text-dark">💻 All Primary Reports</h2>

      <div class="row g-4 justify-content-center">

      <!-- Classes (Navy) -->
        <div class="col-md-3 col-sm-6">
          <div class="dashboard-card card-navy" onclick="location.href='/student_management/reports/primary/ecdA'">
            <div>🏫</div>
            <div class="count"><?php echo $totalECDA; ?></div>
            <h3>ECD A</h3>
          </div>
        </div>

        <!-- Classes (Navy) -->
        <div class="col-md-3 col-sm-6">
          <div class="dashboard-card card-orange" onclick="location.href='/student_management/reports/primary/ecdB'">
            <div>🏫</div>
            <div class="count"><?php echo $totalECDB; ?></div>
            <h3>ECD B</h3>
          </div>
        </div>

<!-- Classes (Navy) -->
        <div class="col-md-3 col-sm-6">
          <div class="dashboard-card card-navy" onclick="location.href='/student_management/reports/primary/grade1'">
            <div>🏫</div>
            <div class="count"><?php echo $totalGrade1; ?></div>
            <h3>Grade 1</h3>
          </div>
        </div>

        <!-- Classes (Navy) -->
        <div class="col-md-3 col-sm-6">
          <div class="dashboard-card card-orange" onclick="location.href='/student_management/reports/primary/grade2'">
            <div>🏫</div>
            <div class="count"><?php echo $totalGrade2; ?></div>
            <h3>Grade 2</h3>
          </div>
        </div>

        <!-- Classes (Navy) -->
        <div class="col-md-3 col-sm-6">
          <div class="dashboard-card card-navy" onclick="location.href='/student_management/reports/primary/grade3'">
            <div>🏫</div>
            <div class="count"><?php echo $totalGrade3; ?></div>
            <h3>Grade 3</h3>
          </div>
        </div>

        <!-- Students (Orange) -->
        <div class="col-md-3 col-sm-6">
          <div class="dashboard-card card-orange" onclick="location.href='/student_management/reports/primary/grade4'">
            <div>👩‍🎓</div>
            <div class="count"><?php echo $totalGrade4; ?></div>
            <h3>Grade 4</h3>
          </div>
        </div>

        <!-- Classes (Navy) -->
        <div class="col-md-3 col-sm-6">
          <div class="dashboard-card card-navy" onclick="location.href='/student_management/reports/primary/grade5'">
            <div>🏫</div>
            <div class="count"><?php echo $totalGrade5; ?></div>
            <h3>Grade 5</h3>
          </div>
        </div>

        <!-- Groups (Orange) -->
        <div class="col-md-3 col-sm-6">
          <div class="dashboard-card card-orange" onclick="location.href='/student_management/reports/primary/grade6'">
            <div>👥</div>
            <div class="count"><?php echo $totalGrade6; ?></div>
            <h3>Grade 6</h3>
          </div>
        </div>

        <!-- Machines (Navy) -->
        <div class="col-md-3 col-sm-6">
          <div class="dashboard-card card-navy" onclick="location.href='/student_management/reports/primary/grade7'">
            <div>💻</div>
            <div class="count"><?php echo $totalGrade7; ?></div>
            <h3>Grade 7</h3>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script src="assets/css/bootstrap-5.3.8-dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
