<?php 
include 'db.php';

// Initialize error messages
$add_error = '';
$edit_error = '';

// Handle Add Group
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_group'])) {
    $group_name = trim($_POST['group_name']);
    if (!empty($group_name)) {
        $stmt = $conn->prepare("SELECT * FROM student_group WHERE group_name=?");
        $stmt->bind_param("s", $group_name);
        $stmt->execute();
        $res = $stmt->get_result();
        if ($res->num_rows == 0) {
            $insert = $conn->prepare("INSERT INTO student_group (group_name) VALUES (?)");
            $insert->bind_param("s", $group_name);
            if ($insert->execute()) {
                header("Location: add_group.php"); 
                exit();
            } else {
                $add_error = "Error: " . $insert->error;
            }
            $insert->close();
        } else {
            $add_error = "This group already exists.";
        }
        $stmt->close();
    } else {
        $add_error = "Please enter a group name.";
    }
}

// Handle Edit Group
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['edit_group'])) {
    $id = intval($_POST['id']);
    $group_name = trim($_POST['group_name']);
    if (!empty($group_name)) {
        $stmt = $conn->prepare("SELECT * FROM student_group WHERE group_name=? AND id<>?");
        $stmt->bind_param("si", $group_name, $id);
        $stmt->execute();
        $res = $stmt->get_result();
        if ($res->num_rows == 0) {
            $update = $conn->prepare("UPDATE student_group SET group_name=? WHERE id=?");
            $update->bind_param("si", $group_name, $id);
            if ($update->execute()) {
                header("Location: add_group.php"); 
                exit();
            } else {
                $edit_error = "Error: " . $update->error;
            }
            $update->close();
        } else {
            $edit_error = "Another group with this name already exists.";
        }
        $stmt->close();
    } else {
        $edit_error = "Please enter a group name.";
    }
}

// Handle Delete Group
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_group'])) {
    $id = intval($_POST['delete_id']);
    $stmt = $conn->prepare("DELETE FROM student_group WHERE id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
    header("Location: add_group.php"); 
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Group Management</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/dataTables.bootstrap5.min.css">
<link href="assets/css/bootstrap-5.3.8-dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body { background-color: #f8f9fa; display: flex; }
.sidebar { width: 250px; height: 100vh; background-color: #001f3f; color: white; padding: 20px; position: sticky; top: 0; }
.sidebar a { color: white; text-decoration: none; display: block; padding: 10px 15px; margin-bottom: 10px; border-radius: 8px; transition: 0.3s; }
.sidebar a:hover, .sidebar a.active { background-color: #ff851b; color: #001f3f; font-weight: bold; }
.sidebar .logout-btn { background-color: #ff4136; color: white; text-align: center; padding: 10px; border-radius: 8px; text-decoration: none; display: block; }
.sidebar .logout-btn:hover { background-color: #ff6347; }
.main-content { flex-grow: 1; padding: 30px; }
.my_btn { background-color: #ff8c00; color: white; }
.my_btn2 { background-color: #001f3f; color:white; }
</style>
</head>
<body>
<?php include 'sidebar.php'; ?>

<div class="main-content">
  <h3 class="text-center mb-4 text-dark">Group Management</h3>

  <?php if ($add_error) echo "<div class='alert alert-warning'>{$add_error}</div>"; ?>
  <?php if ($edit_error) echo "<div class='alert alert-warning'>{$edit_error}</div>"; ?>

 <div class="row mb-3 align-items-center">
  <div class="col-md-4">
    <input type="text" id="tableSearch" class="form-control" placeholder="🔍 Search groups...">
  </div>
  <div class="col-md-4 text-end ms-auto">
    <button class="btn my_btn" data-bs-toggle="modal" data-bs-target="#addGroupModal">+ Add New Group</button>
  </div>
</div>


  <div class="card p-3 mb-4 shadow-sm">
    <table id="groupTable" class="table table-bordered table-striped">
      <thead>
        <tr>
          <th>#</th>
          <th>Group Name</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $groups = $conn->query("SELECT * FROM student_group ORDER BY id DESC");
        if ($groups->num_rows > 0) {
            while ($row = $groups->fetch_assoc()) {
                $id = $row['id'];
                $name = htmlspecialchars($row['group_name'], ENT_QUOTES);
                echo "<tr>
                        <td>{$id}</td>
                        <td>{$name}</td>
                        <td>
                          <div class='d-flex gap-2 w-100'>
                            <button class='btn btn-sm my_btn2 flex-fill edit-btn' 
                                    data-id='{$id}' 
                                    data-name='{$name}' 
                                    data-bs-toggle='modal' 
                                    data-bs-target='#editGroupModal'>Edit</button>
                            <button class='btn btn-sm btn-danger flex-fill delete-btn' 
                                    data-id='{$id}' 
                                    data-name='{$name}' 
                                    data-bs-toggle='modal' 
                                    data-bs-target='#deleteGroupModal'>Delete</button>
                          </div>
                        </td>
                      </tr>";
            }
        } else {
            echo "<tr><td colspan='3' class='text-center'>No groups found</td></tr>";
        }
        ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Add Group Modal -->
<!-- Add Group Modal -->
<div class="modal fade" id="addGroupModal" tabindex="-1" aria-labelledby="addGroupModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form method="post" action="add_group.php">
        <div class="modal-header">
          <h5 class="modal-title" id="addGroupModalLabel">Add New Group</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>

        <div class="modal-body">
          <div class="mb-3">
            <label for="groupName" class="form-label">Group Name</label>
            <input type="text" class="form-control" id="groupName" name="group_name" required>
          </div>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-success">Save Group</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Edit Group Modal -->
<div class="modal fade" id="editGroupModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form method="POST">
        <div class="modal-header bg-primary text-white">
          <h5 class="modal-title">Edit Group</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <input type="hidden" name="edit_group" value="1">
        <input type="hidden" name="id" id="editGroupId">
        <div class="modal-body">
          <div class="mb-3">
            <label>Group Name</label>
            <input type="text" name="group_name" id="editGroupName" class="form-control" required>
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-primary">Update</button>
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Delete Group Modal -->
<div class="modal fade" id="deleteGroupModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form method="POST">
        <div class="modal-header bg-danger text-white">
          <h5 class="modal-title">Delete Group</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <input type="hidden" name="delete_group" value="1">
        <input type="hidden" name="delete_id" id="deleteGroupId">
        <div class="modal-body">
          <p>Are you sure you want to delete the group <strong id="deleteGroupName"></strong>?</p>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-danger">Yes, Delete</button>
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/dataTables.bootstrap5.min.js"></script>

<!-- Bootstrap CSS (head section) -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Bootstrap Bundle JS (bottom of page, before </body>) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>


<script>
document.querySelectorAll('.edit-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.getElementById('editGroupId').value = btn.getAttribute('data-id');
    document.getElementById('editGroupName').value = btn.getAttribute('data-name');
  });
});

document.querySelectorAll('.delete-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.getElementById('deleteGroupId').value = btn.getAttribute('data-id');
    document.getElementById('deleteGroupName').textContent = btn.getAttribute('data-name');
  });
});

document.getElementById("tableSearch").addEventListener("keyup", function() {
  var input = this.value.toLowerCase();
  var rows = document.querySelectorAll("table tbody tr");
  rows.forEach(function(row) {
    let text = row.textContent.toLowerCase();
    row.style.display = text.includes(input) ? "" : "none";
  });
});

$(document).ready(function() {
    $('#groupTable').DataTable({
        "order": [],
        "columnDefs": [{ "orderable": false, "targets": -1 }]
    });
});
</script>
<script src="assets/css/bootstrap-5.3.8-dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
