<?php
include 'db.php';

// Initialize error messages
$add_error = '';
$edit_error = '';

// Handle Add Machine
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_machine'])) {
    $number = trim($_POST['number']);
    $mac_address = trim($_POST['mac_address']);

    if (!empty($number)) {
        // Check for duplicate number or MAC
        $stmt = $conn->prepare("SELECT * FROM machine_number WHERE number = ? OR mac_address = ?");
        $stmt->bind_param("ss", $number, $mac_address);
        $stmt->execute();
        $res = $stmt->get_result();

        if ($res->num_rows > 0) {
            $add_error = "This machine number or MAC address already exists.";
        } else {
            $insert = $conn->prepare("INSERT INTO machine_number (number, mac_address) VALUES (?, ?)");
            $insert->bind_param("ss", $number, $mac_address);
            if ($insert->execute()) {
                header("Location: /computer-lab/machines");
                exit();
            } else {
                $add_error = "Error: " . $insert->error;
            }
            $insert->close();
        }
        $stmt->close();
    } else {
        $add_error = "Please enter a machine number.";
    }
}

// Handle Update Machine
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_machine'])) {
    $id = intval($_POST['edit_id']);
    $number = trim($_POST['edit_number']);
    $mac_address = trim($_POST['edit_mac']);

    // Check duplicates excluding current ID
    $stmt = $conn->prepare("SELECT * FROM machine_number WHERE (number = ? OR mac_address = ?) AND id != ?");
    $stmt->bind_param("ssi", $number, $mac_address, $id);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($res->num_rows > 0) {
        $edit_error = "Another machine with this number or MAC address already exists.";
    } else {
        $update = $conn->prepare("UPDATE machine_number SET number = ?, mac_address = ? WHERE id = ?");
        $update->bind_param("ssi", $number, $mac_address, $id);
        if ($update->execute()) {
            header("Location: /computer-lab/machines");
            exit();
        } else {
            $edit_error = "Error: " . $update->error;
        }
        $update->close();
    }
    $stmt->close();
}

// Handle Delete Machine
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_machine'])) {
    $id = intval($_POST['delete_id']);
    $stmt = $conn->prepare("DELETE FROM machine_number WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
    header("Location: /computer-lab/machines");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Machine Management</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/dataTables.bootstrap5.min.css">
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/dataTables.bootstrap5.min.js"></script>
<link href="assets/css/bootstrap-5.3.8-dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body { background-color: #f8f9fa; display: flex; }
.sidebar { width: 250px; height: 100vh; background-color: #001f3f; color: white; padding: 20px; position: sticky; top: 0; }
.sidebar a { color: white; text-decoration: none; display: block; padding: 10px 15px; margin-bottom: 10px; border-radius: 8px; transition: 0.3s; }
.sidebar a:hover, .sidebar a.active { background-color: #ff851b; color: #001f3f; font-weight: bold; }
.sidebar .logout-btn { background-color: #ff4136; color: white; text-align: center; padding: 10px; border-radius: 8px; text-decoration: none; display: block; }
.sidebar .logout-btn:hover { background-color: #ff6347; }
.main-content { flex-grow: 1; padding: 30px; }
.my_btn { background-color: #ff8c00; }
.my_btn2 { background-color: #001f3f; color:white;}
</style>
<script>
function fillEditModal(id, number, mac) {
    document.getElementById('edit_id').value = id;
    document.getElementById('edit_number').value = number;
    document.getElementById('edit_mac').value = mac;
}

function fillDeleteModal(id, number) {
    document.getElementById('delete_id').value = id;
    document.getElementById('delete_name').textContent = number;
}
</script>
</head>
<body>
<?php include 'sidebar.php'; ?>

<div class="main-content">
<h3 class="text-center mb-4 text-dark">Machine Management</h3>

<?php
// Show errors above the modals
if ($add_error) {
    echo "<div class='alert alert-warning'>{$add_error}</div>";
}
if ($edit_error) {
    echo "<div class='alert alert-warning'>{$edit_error}</div>";
}
?>

<div class="row mb-3 align-items-center">
  <div class="col-md-4">
    <input type="text" id="tableSearch" class="form-control" placeholder="🔍 Search machines...">
  </div>
  <div class="col-md-4 text-end ms-auto">
    <button class="btn my_btn" data-bs-toggle="modal" data-bs-target="#addModal">+ Add New Machine</button>
  </div>
</div>
<div class="card mb-4 shadow-sm border-0">
    <div class="card-body">
        <table id="machineTable" class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Machine Number</th>
                    <th>MAC Address</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            <?php
            $result = $conn->query("SELECT * FROM machine_number ORDER BY id DESC");
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $id = $row['id'];
                    $number = htmlspecialchars($row['number'], ENT_QUOTES);
                    $mac = htmlspecialchars($row['mac_address'], ENT_QUOTES);
                    echo "<tr>
                        <td>{$id}</td>
                        <td>{$number}</td>
                        <td>{$mac}</td>
                        <td>
                            <div class='d-flex gap-2 w-100'>
                                <button class='btn btn-sm my_btn2 flex-fill' data-bs-toggle='modal' data-bs-target='#editModal' 
                                    onclick=\"fillEditModal('{$id}', '{$number}', '{$mac}')\">Edit</button>
                                <button class='btn btn-sm btn-danger flex-fill' data-bs-toggle='modal' data-bs-target='#deleteModal' 
                                    onclick=\"fillDeleteModal('{$id}', '{$number}')\">Delete</button>
                            </div>
                        </td>
                    </tr>";
                }
            } else {
                echo "<tr><td colspan='4' class='text-center'>No records found</td></tr>";
            }
            ?>
            </tbody>
        </table>
    </div>
</div>


<!-- Add Modal -->
<div class="modal fade" id="addModal" tabindex="-1" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<form method="POST">
<div class="modal-header bg-success text-white">
<h5 class="modal-title">Add New Machine</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal"></button>
</div>
<div class="modal-body">
<input type="hidden" name="add_machine" value="1">
<div class="mb-3">
<label>Machine Number</label>
<input type="number" name="number" class="form-control" placeholder="e.g. PC-01" required>
</div>
<div class="mb-3">
<label>MAC Address</label>
<input type="text" name="mac_address" class="form-control" placeholder="e.g. 00:1A:2B:3C:4D:5E" required>
</div>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
<button type="submit" class="btn btn-success">Save</button>
</div>
</form>
</div>
</div>
</div>

<!-- Edit Modal -->
<div class="modal fade" id="editModal" tabindex="-1" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<form method="POST">
<div class="modal-header bg-primary text-white">
<h5 class="modal-title">Edit Machine</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal"></button>
</div>
<div class="modal-body">
<input type="hidden" name="edit_id" id="edit_id">
<div class="mb-3">
<label>Machine Number</label>
<input type="number" name="edit_number" id="edit_number" class="form-control" required>
</div>
<div class="mb-3">
<label>MAC Address</label>
<input type="text" name="edit_mac" id="edit_mac" class="form-control" required>
</div>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
<button type="submit" name="update_machine" class="btn btn-primary">Update</button>
</div>
</form>
</div>
</div>
</div>

<!-- Delete Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<form method="POST">
<input type="hidden" name="delete_machine" value="1">
<input type="hidden" name="delete_id" id="delete_id">
<div class="modal-header bg-danger text-white">
<h5 class="modal-title">Delete Machine</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal"></button>
</div>
<div class="modal-body">
Are you sure you want to delete <strong id="delete_name"></strong>?
</div>
<div class="modal-footer">
<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
<button type="submit" class="btn btn-danger">Yes, Delete</button>
</div>
</form>
</div>
</div>
</div>

</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
document.getElementById("tableSearch").addEventListener("keyup", function() {
  var input = this.value.toLowerCase();
  var rows = document.querySelectorAll("table tbody tr");

  rows.forEach(function(row) {
    let text = row.textContent.toLowerCase();
    row.style.display = text.includes(input) ? "" : "none";
  });
});
</script>

<script>
$(document).ready(function() {
    $('#machineTable').DataTable({
        "order": [], // No default ordering
        "columnDefs": [
            { "orderable": false, "targets": -1 } // Disable sorting for Action column
        ]
    });
});
</script>
<script src="assets/css/bootstrap-5.3.8-dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
