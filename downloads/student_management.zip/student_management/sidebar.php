<?php
$currentPage = basename($_SERVER['PHP_SELF']);
?>

<div class="sidebar">
  <h4 class="text-center mb-4">💻 Lab System</h4>

  <a href="/student_management/home" class="<?= $currentPage == 'index.php' ? 'active' : '' ?>">Dashboard</a>
  <a href="/student_management/students" class="<?= $currentPage == 'add_student.php' ? 'active' : '' ?>">Manage Student</a>
  <a href="/student_management/classes" class="<?= $currentPage == 'add_class.php' ? 'active' : '' ?>">Manage Class</a>
  <a href="/student_management/groups" class="<?= $currentPage == 'add_group.php' ? 'active' : '' ?>">Manage Group</a>
  <a href="/student_management/machines" class="<?= $currentPage == 'add_machine.php' ? 'active' : '' ?>">Manage Machine</a>
  <a href="/student_management/reports/reports">Reports</a>

  <a href="/student_management/logs" class="<?= $currentPage == 'logout.php' ? 'active' : '' ?> logout-btn mt-4" >Logout</a>
</div>
